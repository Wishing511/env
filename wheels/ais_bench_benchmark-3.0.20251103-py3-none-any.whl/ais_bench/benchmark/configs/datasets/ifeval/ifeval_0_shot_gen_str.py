from ais_bench.benchmark.openicl.icl_prompt_template import PromptTemplate
from ais_bench.benchmark.openicl.icl_retriever import ZeroRetriever
from ais_bench.benchmark.openicl.icl_inferencer import GenInferencer
from ais_bench.benchmark.datasets.ifeval import IFEvalDataset, IFEvaluator

ifeval_reader_cfg = dict(
    input_columns=['prompt'], output_column='reference')

ifeval_infer_cfg = dict(
    prompt_template=dict(
        type=PromptTemplate,
        template='{prompt}'
    ),
    retriever=dict(type=ZeroRetriever),
    inferencer=dict(type=GenInferencer))

ifeval_eval_cfg = dict(
    evaluator=dict(type=IFEvaluator),
)

ifeval_datasets = [
    dict(
        abbr='ifeval',
        type=IFEvalDataset,
        path='ais_bench/datasets/ifeval/input_data.jsonl',
        reader_cfg=ifeval_reader_cfg,
        infer_cfg=ifeval_infer_cfg,
        eval_cfg=ifeval_eval_cfg)
]